/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <math.h>

void writeDig();
void writeNum();
void clearDisplay();
void printInt();
void printDisplay();
void soundBuzzer();
void sendSignal();

int current_mode; // 0: sleep, 1: startup, 2: programming group, 3: programming inches/cm, 4 measuring mode
int group_number = 1;
int max_group_number = 99;
int isCm = 1;
int isSent; // 1 if a pulse has been sent by the ultrasonic 
float travelTimes[10]={0,0,0,0,0,0,0,0,0,0};

int threshold = 50;
int distanceCm;
int distanceCmVal[10];
int distanceCmSum[10];
int distanceCmLen[10];
int distanceCmPrint;
int distanceInPrint;

float speed = 0.0340;
int32 signalSendTime = 0;

int pulse_num = 10; // The number of pulses sent by the ultrasonic on a button press
int32 milli;
int five_mS_Count = 5;
int buzzer = 0;

CY_ISR(TimingISR)
{
    milli++;
    five_mS_Count--;
    if (five_mS_Count == 0) {
        five_mS_Count = 5;
        buzzer--;
    }
    if (buzzer == 0) { // turn off buzzer
        Buzz_Pin_Write(1);
    }
    if (signalSendTime != 0 && signalSendTime < milli){
        if(Button_0_Read()==0) {
            sendSignal(pulse_num);
        } else {
            current_mode = 0;
            signalSendTime = 0;
        }
    }
}

CY_ISR(ButtonISR0)
{
    // Sound the buzzer for 200ms
    Buzz_Pin_Write(0);
    CyDelay(200);
    Buzz_Pin_Write(1);
    
    switch (current_mode){
        case 0:// If sleeping, send out 'n' ultrasonic pulses
            CyDelay(10);
            if ((Button_1_Read()==0)&(Button_0_Read()==0)) {
                CyDelay(1000);
                if((Button_1_Read()==0)&(Button_0_Read()==0)){
                    current_mode = 2;
                    group_number--;
                }
            } else {
                sendSignal(pulse_num);   
            }
            break;
        if ((Button_1_Read()==1)&(Button_0_Read()==1)) {    
        case 2: // If in programming group number mode, increment the group number
            group_number++;
            group_number = group_number>max_group_number ? 0 : group_number; // Ensure group number doesn't go over 99
            EEPROM_WriteByte(group_number, 0);
            writeNum(group_number,1);
            break;
        case 3: // If in programming inches/cm mode, switch display to cm
            isCm = isCm==1 ? 0:1;
            EEPROM_WriteByte(isCm, 1);
            Cm_LED_Write(~isCm);
            clearDisplay();
            if (isCm==1){ // C
                writeDig(4, 10, 1);
            } else { // In
                writeDig(3, 1, 1);
                writeDig(4, 11, 1);
            }
            break;
        case 4:
            if ((Button_1_Read()==0)&(Button_0_Read()==0)) {
                CyDelay(1000);
                if((Button_1_Read()==0)&(Button_0_Read()==0)){
                    current_mode = 2;
                }
            }
            break;
        }
    }
}

CY_ISR(ButtonISR1)
{
    Buzz_Pin_Write(0);
    CyDelay(200);
    Buzz_Pin_Write(1);
    if (current_mode == 0) {
        if ((Button_1_Read()==0)&(Button_0_Read()==0)) {
            CyDelay(1000);
            if((Button_1_Read()==0)&(Button_0_Read()==0)) {
                current_mode = 2;
                group_number--;
            }
        }
    } else {

            switch (current_mode){
                case 2: // If in programming group number mode, decrement the group number
                    group_number--;
                    group_number = group_number<0 ? max_group_number : group_number; // Ensure group number doesn't go below 0
                    EEPROM_WriteByte(group_number, 0);
                    writeNum(group_number,1);
                    break;
                case 3: // If in programming inches/cm mode, switch display to inches
                    isCm = isCm==1 ? 0:1;
                    EEPROM_WriteByte(isCm, 1);
                    Cm_LED_Write(~isCm);
                    clearDisplay();
                    if (isCm==1){ // C
                        writeDig(4, 10, 1);
                    } else { // In
                        writeDig(3, 1, 1);
                        writeDig(4, 11, 1);
                    }
                    break;
                case 4:
                    if ((Button_1_Read()==0)&(Button_0_Read()==0)) {
                        CyDelay(1000);
                        if((Button_1_Read()==0)&(Button_0_Read()==0)){
                            current_mode = 2;
                        }
                    }
                    break;
            
        }
    }
}

CY_ISR(ButtonISR2)
{
    Buzz_Pin_Write(0);
    CyDelay(200);
    Buzz_Pin_Write(1);
    switch (current_mode) {
        case 2: // If in programming group number mode, switch to programming inches/cm mode
            current_mode = 3;
            break;
        case 3: // If in programming group inches/cm mode, go back to sleep
            current_mode = 0;
            break;
    }
}

CY_ISR(ButtonISR3) // Toggles cm/In whenever the 4th button is pressed
{
    Buzz_Pin_Write(0);
    CyDelay(200);
    Buzz_Pin_Write(1);
    if (current_mode == 0 || current_mode == 4){
        isCm = isCm==1?0:1;
        Cm_LED_Write(~isCm);
        EEPROM_WriteByte(isCm, 1);
        writeNum(isCm==1 ? distanceCmPrint : distanceInPrint,0);
        CyDelay(500);
    }
}

CY_ISR(DistanceISR)
{
    if (isSent==1) {
        isSent = 0;
        for (int i=0;i<10;i++) {
            if (travelTimes[i]==0) {
                travelTimes[i] = 256 - Timer_1_ReadCapture();
                break;
            }
        }
    }
        
    Timer_1_ReadStatusRegister();
}

int main(void)
{
    current_mode = 1; // Enable startup mode
    
    // Initialize components
    PGA_1_Start();
    Opamp_1_Start();
    Comp_1_Start();
    VDAC8_1_Start();
    Timer_1_Start();
    Timer_2_Start();
    EEPROM_Start();
    ultrasonic_clock_Stop();
    
    // Enable interrupts
    CyGlobalIntEnable;
    dist_isr_ClearPending();
    button_0_isr_ClearPending();
    button_1_isr_ClearPending();
    button_2_isr_ClearPending();
    button_3_isr_ClearPending();
    timing_isr_ClearPending();
    
    dist_isr_StartEx(DistanceISR);
    button_0_isr_StartEx(ButtonISR0);
    button_1_isr_StartEx(ButtonISR1);
    button_2_isr_StartEx(ButtonISR2);
    button_3_isr_StartEx(ButtonISR3);
    timing_isr_StartEx(TimingISR);
    
    // Load variables from EEPROM
    
    group_number = EEPROM_ReadByte(0);
    isCm = EEPROM_ReadByte(1);
    
    // Light up all LEDs on each digit with a 1 second delay between digits
    
    Cm_LED_Write(~isCm);
    
    for (int i=1; i<5; i++){
        writeDig(i,8,0);
        CyDelay(1000);
        writeDig(i,12,1);
    }
    
    // Check each number works
    
    /*for (int i=0; i<10; i++){
        writeDig(1,i,1);
        writeDig(2,i,1);
        writeDig(3,i,1);
        writeDig(4,i,1);
        CyDelay(1000);
    }
    clearDisplay();
    */
    
    // Display group number
    writeNum(group_number,1);
    CyDelay(1000);
    clearDisplay();
    
    // Display C/In
    if (isCm==1){ // C
        writeDig(4, 10, 1);
    } else { // In
        writeDig(3, 1, 1);
        writeDig(4, 11, 1);
    }
    CyDelay(1000);
    clearDisplay();
    
    current_mode = 0; // go to sleep
    
    CyDelay(1000);
    
    for (;;){ // main loop
        switch(current_mode){
            case 0: // While sleeping, blink the dp on the last LED
                clearDisplay();
                writeDig(1,12,0);
                CyDelay(500);
                clearDisplay();
                CyDelay(1000);
                break;
            case 2: // While in group programming mode, flash the group number
                writeNum(group_number,1);
                CyDelay(1000);
                clearDisplay();
                CyDelay(500);
                break;
            case 3: // While in C/In programming mode, flash the mode
                clearDisplay();
                if (isCm==1){ // C
                    writeDig(4, 10, 1);
                } else { // In
                    writeDig(3, 1, 1);
                    writeDig(4, 11, 1);
                }
                CyDelay(1000);
                clearDisplay();
                CyDelay(500);
                break;
            case 4: // While in sensor mode, print the currently detected distance
                if (travelTimes[0] != 0)
                {
                    // Reset the buckets
                    for (int i=0; i<10; i++){
                        distanceCmVal[i]=0;
                        distanceCmSum[i]=0;
                        distanceCmLen[i]=0;
                    }
                    
                    // Calculate the distances and put them in buckets based on how close together they are
                    for (int i=0; i<10; i++){
                        //distanceCm = ((travelTimes[i]*10*speed-8.02)/2.15*100); // inital calibration
                        distanceCm = ((travelTimes[i]*10*speed-7.64)/2.1*100); // new calibration
                        //distanceCm = ((travelTimes[i]*10*speed)*100); // used for calibration
                        distanceCm = (int)distanceCm;
                        for(int j=0;j<10;j++){
                            // Check over each bucket to see if its empty, or if its within range
                            if (distanceCmLen[j]==0){
                                distanceCmVal[j] = distanceCm;
                            }
                            
                            if (distanceCmVal[j]-threshold<distanceCm && distanceCmVal[j]+threshold>distanceCm){
                                distanceCmLen[j]++;
                                distanceCmSum[j] += distanceCm;
                                break;
                            }
                        }
                        
                        travelTimes[i] = 0;
                    }
                    
                    // Find the largest bucket
                    int maxLen = 0;
                    int selectedBucket = 0;
                    for (int i=0; i<10; i++){
                        if (distanceCmLen[i] > maxLen){
                            maxLen = distanceCmLen[i];
                            selectedBucket = i;
                        }
                    }
                    
                    distanceCmPrint = distanceCmSum[selectedBucket] / distanceCmLen[selectedBucket]; // Finding the average
                    distanceCmPrint = (int)distanceCmPrint; // Casting as an integer

                    // Print the distance to the LED screen
                    distanceInPrint = distanceCmPrint*0.3937008; // Conversion to inches
                    distanceInPrint = (int)distanceInPrint;
                    writeNum(isCm==1 ? distanceCmPrint : distanceInPrint,0); // Choosing which units to print
                    
                    // Wait 2 secs then print again
                    CyDelay(2000);
                }
                break;
        }
    }
}

void writeNum(int num, int isFull) // Writes a <=4 digit number to the LED screen
{ 
    // Working out each digit
    int num1 = num % 10;
    num -= num1;
    int num2 = (num % 100)/10;
    num -= num2;
    int num3 = (num % 1000)/100;
    num -= num3;
    int num4 = (num % 10000)/1000;
    
    // Writing them to screen
    writeDig(1,num4,1);
    writeDig(2,num3,isFull);
    writeDig(3,num2,1);
    writeDig(4,num1,1);
}

void writeDig(int pos, int num, int dp) // Light up a digit
{
    // Array determining which pins to light up dependent on the given number
    uint8 num_to_pin[13] = {
        0x02, //00000010 0
        0x9E, //10011110 1
        0x24, //00100100 2
        0x0c, //00001100 3
        0x98, //10011000 4
        0x48, //01001000 5
        0x40, //01000000 6
        0x1E, //00011110 7
        0x00, //00000000 8
        0x08, //00001000 9
        0x62, //01100010 C
        0xD4, //11010100 n
        0xFE  //11111110 blank
    };
    
    uint8 val = num_to_pin[num]+dp;
    
    // Writing to the digit selector pins
    switch (pos) {
        case 1:
            Dig_1_Write(val);
            break;
        case 2:
            Dig_2_Write(val);
            break;
        case 3:
            Dig_3_Write(val);
            break;
        case 4:
            Dig_4_Write(val);
            break;
    }
}

void clearDisplay() // Clears the display
{
    writeDig(1,12,1);
    writeDig(2,12,1);
    writeDig(3,12,1);
    writeDig(4,12,1);
}

void soundBuzzer(int duration) // Sounds the buzzer for a given duration in ms
{
    Buzz_Pin_Write(0);
    CyDelay(duration);
    Buzz_Pin_Write(1);
}

void sendSignal(int pulse_num) // Sends out a signal from the ultrasonic sensor 'pulse_num' times
{
    current_mode = 4;
    for (int i=0; i<10; i++){
        travelTimes[i] = 0;
    }
    for (int i=0; i<pulse_num; i++){
        // Reset the timer
        Timer_Reset_Write(1);
        CyDelayUs(100);
        Timer_Reset_Write(0);
        
        // Pulse the ultrasonic 10 times
        ultrasonic_clock_Start();
        isSent=1;
        CyDelayUs(250);
        ultrasonic_clock_Stop();
        
        // Wait for the signal to come back before pulsing again
        CyDelay(6); // Waits for signals less than ~1m away
    }
    // Send another signal after 2s if holding down the button
    signalSendTime = milli + 2000;
}

/* [] END OF FILE */
